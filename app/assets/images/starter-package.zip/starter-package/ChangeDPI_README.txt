2. Move 'ChangeDPI.jsx' to Applications > Adobe InDesign CS6 > Scripts > Scripts Panel > Samples > Javascript
3. Open InDesign:  Go to Window > Utilities > Scripts
4. Locate ChangeDPI script and double click.
5. Zoom in 100% and make sure it's 960px wide now.